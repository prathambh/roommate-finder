const roommatesData = [
    {id:1,picture:`/images/${randomImage("Male")}.png`,name:"John Doe",maxRent:832,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:2,picture:`/images/${randomImage("Female")}.png`,name:"Jane Smith",maxRent:1032,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:3,picture:`/images/${randomImage("Male")}.png`,name:"Michael Johnson",maxRent:625,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:4,picture:`/images/${randomImage("Female")}.png`,name:"Emily Brown",maxRent:1073,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:5,picture:`/images/${randomImage("Male")}.png`,name:"James Wilson",maxRent:1124,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:6,picture:`/images/${randomImage("Female")}.png`,name:"Emma Taylor",maxRent:702,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:7,picture:`/images/${randomImage("Male")}.png`,name:"William White",maxRent:798,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:8,picture:`/images/${randomImage("Female")}.png`,name:"Olivia Anderson",maxRent:896,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:9,picture:`/images/${randomImage("Male")}.png`,name:"Daniel Thomas",maxRent:1036,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:10,picture:`/images/${randomImage("Female")}.png`,name:"Sophia Martinez",maxRent:1078,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue with more data
    {id:11,picture:`/images/${randomImage("Male")}.png`,name:"David Garcia",maxRent:963,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:12,picture:`/images/${randomImage("Female")}.png`,name:"Isabella Rodriguez",maxRent:742,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:13,picture:`/images/${randomImage("Male")}.png`,name:"Ethan Martinez",maxRent:1156,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:14,picture:`/images/${randomImage("Female")}.png`,name:"Mia Lopez",maxRent:1104,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:15,picture:`/images/${randomImage("Male")}.png`,name:"Alexander Lee",maxRent:982,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:16,picture:`/images/${randomImage("Female")}.png`,name:"Sophia Garcia",maxRent:705,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:17,picture:`/images/${randomImage("Male")}.png`,name:"Benjamin Lopez",maxRent:812,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:18,picture:`/images/${randomImage("Female")}.png`,name:"Amelia Clark",maxRent:998,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:19,picture:`/images/${randomImage("Male")}.png`,name:"Elijah Taylor",maxRent:1042,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:20,picture:`/images/${randomImage("Female")}.png`,name:"Charlotte Adams",maxRent:899,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue with more data
    {id:21,picture:`/images/${randomImage("Male")}.png`,name:"Liam Hernandez",maxRent:845,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:22,picture:`/images/${randomImage("Female")}.png`,name:"Amelia Garcia",maxRent:723,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:23,picture:`/images/${randomImage("Male")}.png`,name:"Lucas Miller",maxRent:1065,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:24,picture:`/images/${randomImage("Female")}.png`,name:"Ella Moore",maxRent:1115,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:25,picture:`/images/${randomImage("Male")}.png`,name:"Mason Davis",maxRent:902,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:26,picture:`/images/${randomImage("Female")}.png`,name:"Ava Martinez",maxRent:721,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:27,picture:`/images/${randomImage("Male")}.png`,name:"Logan Wilson",maxRent:789,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:28,picture:`/images/${randomImage("Female")}.png`,name:"Harper Thompson",maxRent:852,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:29,picture:`/images/${randomImage("Male")}.png`,name:"Jackson Harris",maxRent:1069,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:30,picture:`/images/${randomImage("Female")}.png`,name:"Luna Brown",maxRent:1198,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue with more data
    {id:31,picture:`/images/${randomImage("Male")}.png`,name:"Mateo Hernandez",maxRent:952,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:32,picture:`/images/${randomImage("Female")}.png`,name:"Scarlett Rodriguez",maxRent:774,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:33,picture:`/images/${randomImage("Male")}.png`,name:"Liam Martin",maxRent:1156,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:34,picture:`/images/${randomImage("Female")}.png`,name:"Chloe Adams",maxRent:1187,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:35,picture:`/images/${randomImage("Male")}.png`,name:"Noah Wilson",maxRent:874,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:36,picture:`/images/${randomImage("Female")}.png`,name:"Emma Garcia",maxRent:799,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:37,picture:`/images/${randomImage("Male")}.png`,name:"Lucas Thompson",maxRent:942,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:38,picture:`/images/${randomImage("Female")}.png`,name:"Avery Clark",maxRent:898,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:39,picture:`/images/${randomImage("Male")}.png`,name:"Aiden Rodriguez",maxRent:1053,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:40,picture:`/images/${randomImage("Female")}.png`,name:"Grace Martinez",maxRent:1129,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue with more data
    {id:41,picture:`/images/${randomImage("Male")}.png`,name:"Carter Brown",maxRent:978,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:42,picture:`/images/${randomImage("Female")}.png`,name:"Madison Hernandez",maxRent:824,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:43,picture:`/images/${randomImage("Female")}.png`,name:"Henry Wilson",maxRent:1147,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:44,picture:`/images/${randomImage("Female")}.png`,name:"Aria Clark",maxRent:1202,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:45,picture:`/images/${randomImage("Male")}.png`,name:"Michael Davis",maxRent:837,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:46,picture:`/images/${randomImage("Female")}.png`,name:"Evelyn Thompson",maxRent:795,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:47,picture:`/images/${randomImage("Male")}.png`,name:"Sebastian Martinez",maxRent:906,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:48,picture:`/images/${randomImage("Female")}.png`,name:"Ella Adams",maxRent:998,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:49,picture:`/images/${randomImage("Male")}.png`,name:"Gabriel Rodriguez",maxRent:1023,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:50,picture:`/images/${randomImage("Female")}.png`,name:"Aurora Martinez",maxRent:1116,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue with more data
    {id:51,picture:`/images/${randomImage("Male")}.png`,name:"Liam Moore",maxRent:931,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:52,picture:`/images/${randomImage("Female")}.png`,name:"Evelyn Harris",maxRent:789,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:53,picture:`/images/${randomImage("Male")}.png`,name:"Jackson Martinez",maxRent:1152,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:54,picture:`/images/${randomImage("Female")}.png`,name:"Aria Martin",maxRent:1219,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:55,picture:`/images/${randomImage("Male")}.png`,name:"Lucas Rodriguez",maxRent:842,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:56,picture:`/images/${randomImage("Female")}.png`,name:"Aurora Brown",maxRent:787,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:57,picture:`/images/${randomImage("Male")}.png`,name:"William Thompson",maxRent:938,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:58,picture:`/images/${randomImage("Female")}.png`,name:"Emily Clark",maxRent:908,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:59,picture:`/images/${randomImage("Male")}.png`,name:"Oliver Rodriguez",maxRent:1056,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:60,picture:`/images/${randomImage("Female")}.png`,name:"Sophia Davis",maxRent:1103,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
    // Continue generating data up to 100 people
    {id:61,picture:`/images/${randomImage("Male")}.png`,name:"Ethan Wilson",maxRent:876,city:"London",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:62,picture:`/images/${randomImage("Female")}.png`,name:"Scarlett Moore",maxRent:805,city:"Manchester",smokingAllowed:true,petAllowed:false,gender:"Female"},
    {id:63,picture:`/images/${randomImage("Male")}.png`,name:"Mason Harris",maxRent:1134,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Male"},
    {id:64,picture:`/images/${randomImage("Female")}.png`,name:"Chloe Adams",maxRent:1178,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Female"},
    {id:65,picture:`/images/${randomImage("Male")}.png`,name:"James Wilson",maxRent:839,city:"Liverpool",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:66,picture:`/images/${randomImage("Female")}.png`,name:"Ava Taylor",maxRent:782,city:"London",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:67,picture:`/images/${randomImage("Male")}.png`,name:"Benjamin Thompson",maxRent:918,city:"Manchester",smokingAllowed:false,petAllowed:false,gender:"Male"},
    {id:68,picture:`/images/${randomImage("Female")}.png`,name:"Charlotte Clark",maxRent:887,city:"Birmingham",smokingAllowed:true,petAllowed:true,gender:"Female"},
    {id:69,picture:`/images/${randomImage("Male")}.png`,name:"Lucas Rodriguez",maxRent:1045,city:"Glasgow",smokingAllowed:false,petAllowed:true,gender:"Male"},
    {id:70,picture:`/images/${randomImage("Female")}.png`,name:"Emma Brown",maxRent:1101,city:"Liverpool",smokingAllowed:true,petAllowed:false,gender:"Female"},
  ];
  function randomImage(gender) {
    const maleImages = ["brownMan", "lightMan"];
    const femaleImages = ["brownWoman", "lightWoman"];
    const images = gender === "Male" ? maleImages : femaleImages;
    const randomIndex = Math.floor(Math.random() * images.length);
    return images[randomIndex];
  }

  
  
  export default roommatesData;
  