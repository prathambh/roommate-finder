import React, { useState } from 'react';
import Card from './components/Card';
import Filter from './components/Filter';
import roommatesData from './data/roommatesData';
import './App.css';

function App() {
  const [filterOptions, setFilterOptions] = useState({
    price: '',
    city: '',
    smoking: '',
    pet: '',
    gender: ''
  });

  const handleFilterChange = (option, value) => {
    setFilterOptions(prevOptions => ({
      ...prevOptions,
      [option]: value
    }));
  };

  const handleResetFilters = () => {
    setFilterOptions({
      price: '',
      city: '',
      smoking: '',
      pet: '',
      gender: ''
    });
  };

  const filteredRoommates = roommatesData.filter(roommate => {
    const priceMatch = filterOptions.price === '' || roommate.maxRent <= parseInt(filterOptions.price);
    const cityMatch = filterOptions.city === '' || roommate.city === filterOptions.city;
    const smokingMatch = filterOptions.smoking === '' || (filterOptions.smoking === 'true' ? roommate.smokingAllowed : !roommate.smokingAllowed);
    const petMatch = filterOptions.pet === '' || (filterOptions.pet === 'true' ? roommate.petAllowed : !roommate.petAllowed);
    const genderMatch = filterOptions.gender === '' || roommate.gender === filterOptions.gender;

    return priceMatch && cityMatch && smokingMatch && petMatch && genderMatch;
  });

  return (
    <div className="App">
      <header className="header">
        <h1>Roommate Finder</h1>
        <Filter onFilterChange={handleFilterChange} onResetFilters={handleResetFilters} />
      </header>
      {filteredRoommates.length > 0 ? (
        <div className="card-container">
          {filteredRoommates.map(roommate => (
            <Card key={roommate.id} roommate={roommate} />
          ))}
        </div>
      ) : (
        <p>No matching roommates found.</p>
      )}
    </div>
  );
}

export default App;
