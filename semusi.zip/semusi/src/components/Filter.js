import React from 'react';

const Filter = ({ onFilterChange, onResetFilters }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    onFilterChange(name, value);
  };

  const handleReset = () => {
    const filterInputs = document.querySelectorAll('.filter select');
    filterInputs.forEach((input) => {
      input.value = ''; // Reset all select inputs to "Any"
    });

    const priceInput = document.getElementById('price');
    priceInput.value = ''; // Reset price input

    onResetFilters();
  };

  return (
    <div className="filter">
      <label htmlFor="price">Price:</label>
      <input type="number" id="price" name="price" onChange={handleChange} />

      <label htmlFor="city">City:</label>
      <select id="city" name="city" onChange={handleChange}>
        <option value="">Select City</option>
        <option value="London">London</option>
        <option value="Manchester">Manchester</option>
        <option value="Birmingham">Birmingham</option>
        <option value="Glasgow">Glasgow</option>
        <option value="Liverpool">Liverpool</option>
      </select>

      <label htmlFor="smoking">Smoking Allowed:</label>
      <select id="smoking" name="smoking" onChange={handleChange}>
        <option value="">Any</option>
        <option value="true">Yes</option>
        <option value="false">No</option>
      </select>

      <label htmlFor="pet">Pet Allowed:</label>
      <select id="pet" name="pet" onChange={handleChange}>
        <option value="">Any</option>
        <option value="true">Yes</option>
        <option value="false">No</option>
      </select>

      <label htmlFor="gender">Gender:</label>
      <select id="gender" name="gender" onChange={handleChange}>
        <option value="">Any</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
      </select>

      <button onClick={handleReset}>Reset Filters</button>
    </div>
  );
};

export default Filter;
