import React from 'react';
import './Card.css';

const Card = ({ roommate }) => {
  let genderColor = '';
  if (roommate.gender === 'Male') {
    genderColor = 'blue-text';
  } else if (roommate.gender === 'Female') {
    genderColor = 'pink-text';
  }

  const handleContactClick = () => {
 
    console.log(`Contact ${roommate.name}`);
  };

  return (
    <div className="card">
      <div className="image-container">
        <img src={roommate.picture} alt="Roommate" />
      </div>
      <div className="card-body">
        <h2>{roommate.name}</h2>
        <p><strong>City:</strong> <span className="bold-text">{roommate.city}</span></p>
        <p><strong>Max Rent:</strong> <span className="blue-text">${roommate.maxRent}</span></p>
        <p><strong>Smoking Allowed:</strong> {roommate.smokingAllowed ? "Yes" : "No"}</p>
        <p><strong>Pet Allowed:</strong> {roommate.petAllowed ? "Yes" : "No"}</p>
        <p><strong>Gender:</strong> <span className={genderColor}>{roommate.gender}</span></p>
        <button className="contact-button" onClick={handleContactClick}>Contact</button>
      </div>
    </div>
  );
};

export default Card;
